class AppSecrets {
  AppSecrets._();

  static const String cloudinaryCloudName = 'dt4ldwhgs';
  static const String cloudinaryUploadPreset = 'nqs8sbia';

  static const String fcmServerKey = 'YOUR_SERVER_KEY_HERE';

  static const String fcmProjectId = 'klassinfo-app';
  static const String fcmClientEmail =
      "firebase-adminsdk-fbsvc@klassinfo-app.iam.gserviceaccount.com";

  static const String fcmPrivateKey =
      "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDMlQTazah9iFqf\nKu8mKaBg5WFXKiN/RZnpePmu5Yh7aBkDgANcRScZhGbWWULEnhS4StbyEgBAR1SC\n6yuDNmKYt7kUn+5WqFLRfrDyoiQJngAhROwpFkaRVrHs1PvPHqmEsDSj099b3Cf8\nSv3IwZeCVfMWNlq+y/U5oYJ+2ny0GS8kYK5bdNghXb+5fv049WPRweC+qjNLoCsu\n/W7eTUpXRJFCz4e9cqpE/FANkE5lz1PFB80LTV4aSqMAPXHXdHuIuR7dxp180gOY\n+tT1mxpOhDDeIKvq+59MZ2lHo/9T2bHcN7jFBMA6iEQLquKKOkhREJ9q90KNzwC+\nKAZv9T8fAgMBAAECggEAHHO7JZ0FilPc2pcThHi0k9VC6Ob04d3xrl1DSFYm2Zbc\nJ7b1gK8jZXKbBMOMPCEKG6lY5HipbUceU0jWl9yH8NpYVKx7brThM76NaGkxXt8J\nAJd/yqUM8mievSPP03ndtJT29TPhs/pV20ooqnN2GUvPz26Gx1NBSx8RsYe8YSWB\nnlAoxQ/ZkWIr+/sSLVlVL8AVHzQChxs7FiCYprxtOHHShMgvA6a7xyNwUotJ+zs2\nWcsLE3zqsvuWlB+DYO+7aEcqAGcJcDEEA901TYOrg9blkhym/xLE4IjkGOkuXmYG\nMjhzfZRSY3qT515UOFOD8HeTTk7vxlCkbfgqWiIiFQKBgQD42895JywkzpSKmLTr\nRbA6V+OqLTZ8hQKx5Ca7XIKl0Z43HmaaDXaI5yQc+99Pc8IBiFejSkaZtvjvyHzo\n+T3LdNrmvyGcVGpAfO6KhDmNHtQ9G2MADXO8wGyK7rfz7D/1dN+Rx2ceEko9bpMZ\n+haNbY1x9ksxFgXeUg8a8UekswKBgQDSc/ChqAqqnB1cOJdz5G0EQh8gReTbPmKn\nalVPYZLOhBNjJ78el3xn+y61emIK02dPXzz+3TZJCD0VGG6wUVqIBm0ljWB9kDPZ\n8qCWCHn48TXDAFDNerLm2YHEahqBv1yaCEBUGQUfDVmN8/Idu5yfoXN7ta/fKCWh\n66qVrijp5QKBgQDnyFNFFCcZYQ8Yx4I6X33z2UhCiDnnYDtSVJ1+hHtq1gH2dGo7\nsa5ldGM+W5lx9u8LXmHBxLxdDv5s1t8AXqQfi4cWw44afMU5qyLCAMVZmw0ynP9o\nXR8e/loaTJ0oozIu+9v/eymf6IkdDpAT8cpvj0neivcdkNWGbAeFoJSJ4QKBgBlN\nFQXqVPXz9NesehDVyoFzjZhsrrnpAyVLdFwpx+OKH2aRVbnQzoUVvqTUxMq2Zbo2\nIfgmEiuvkOBjYpNSBIdL9n1IROxzlLhEIihHdpqGLUd3Vz+M28tDJQW/F9a3ceOW\n0F0L8QCtszGMvXPzpT3PxDmAO1eh1Pxlf8mk+Yg9AoGBAIagCuc0/+b6nw8nrgVv\njUiWggT9JJLn2SmjVP/nD6sCYcePiSWhl8GWdlIwmbFijTImk9kIIUXqntfZ38RB\n+w53617ZnTcV8BiqKYRY1ACl3CVELVhu5qSUeLdnpnn0yshA+bmWxAvk/yN0rMRA\nRvbOAcRRUevG91WdV/W7YwTM\n-----END PRIVATE KEY-----\n";
}
