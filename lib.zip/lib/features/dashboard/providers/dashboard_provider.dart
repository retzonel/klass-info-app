import 'dart:async';
import 'package:flutter/material.dart';
import '../../../core/models/user_model.dart';
import '../../../core/services/firestore_service.dart';
import '../../classes/models/class_model.dart';
import '../../classes/services/class_service.dart';
import '../../../core/services/notification_service.dart';

class DashboardProvider extends ChangeNotifier {
  final FirestoreService _firestoreService = FirestoreService();
  final ClassService _classService = ClassService();

  UserModel? _user;
  List<ClassModel> _classes = [];
  bool _isLoading = false;
  String? _errorMessage;

  UserModel? get user => _user;
  List<ClassModel> get classes => _classes;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  StreamSubscription<UserModel?>? _userSubscription;

  void init(String uid) {
    _userSubscription?.cancel();
    _userSubscription = null;

    _isLoading = true;
    notifyListeners();

    _userSubscription = _firestoreService
        .userStream(uid)
        .listen(
          (user) async {
            _user = user;
            if (user != null && user.joinedClassIds.isNotEmpty) {
              _classes = await _classService.getClassesForUser(
                user.joinedClassIds,
              );

              if (user != null && user.joinedClassIds.isNotEmpty) {
                _classes = await _classService.getClassesForUser(
                  user.joinedClassIds,
                );

                // Re-subscribe to all class topics on every login.
                // subscribeToTopic is idempotent — safe to call multiple times.
                final notificationService = NotificationService();
                for (final classId in user.joinedClassIds) {
                  await notificationService.subscribeToClass(classId);
                }
              }
            } else {
              _classes = [];
            }
            _isLoading = false;
            notifyListeners();
          },
          onError: (error) {
            _errorMessage = 'Failed to load your data. Please restart the app.';
            _isLoading = false;
            notifyListeners();
          },
        );
  }

  void reset() {
    _userSubscription?.cancel();
    _userSubscription = null;
    _user = null;
    _classes = [];
    _isLoading = false;
    _errorMessage = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _userSubscription?.cancel();
    super.dispose();
  }
}
